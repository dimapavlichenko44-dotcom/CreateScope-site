# com.sqrage.youtube_media — native host protocol

Reverse-engineered from the old Sqrage YouTube Downloader extension's `background.js`/`popup.js`
at `C:\Users\Dmytro\AppData\Local\SqrageYouTubeDownloader\Extension\`. The host itself
(`YouTubeMediaHost.exe`) is a compiled binary — this is the only record of its contract.

Registered manifest: `C:\Users\Dmytro\AppData\Local\SqrageYouTubeDownloader\com.sqrage.youtube_media.json`
(stdio native messaging host; `allowed_origins` includes our extension's pinned ID
`chrome-extension://eceboaogflfkcaihnjlhonidblnnnidc/`, which requires the `key` in the root
`manifest.json` to stay unchanged).

One-shot `chrome.runtime.sendNativeMessage`, NOT a persistent port. `download` enqueues and
returns immediately; poll `jobs` for progress. Bundles yt-dlp + ffmpeg; merges video-only +
audio-only formats itself when needed.

## Commands

- `{command: "status"}` → `{ok, ready, message?, ytdlpVersion?}`
- `{command: "formats", url}` → `{ok, formats: [{quality, formatId, width, height, fps, hdr, hasAudio}], maxQuality, message?}`
- `{command: "download", url, mode: "video"|"audio", quality, videoFormatId, videoHasAudio, audioFormat, title}` → `{ok, message?}`
- `{command: "jobs"}` → `{ok, jobs: [{jobId, status, title, label, percent, stage, speed, eta, error}], activeCount}`
  - status: `queued | downloading | processing | completed | failed | cancelled`
- `{command: "cancel", jobId}` → `{ok}`
- `{command: "clear_finished"}` → `{ok}`
- `{command: "open_downloads"}` → `{ok}`
- `{command: "settings"}` → `{ok, downloadFolder, effectiveDownloadFolder, message?}`
- `{command: "set_download_folder", downloadFolder}` → `{ok, downloadFolder, effectiveDownloadFolder}`
- `{command: "choose_download_folder"}` → `{ok, cancelled?, downloadFolder, effectiveDownloadFolder}`
- `{command: "reset_download_folder"}` → `{ok, effectiveDownloadFolder}`
- `{command: "save_image", fileName, mimeType, dataBase64}` → `{ok, outputFile, message?}`

We only use `status`, `formats`, `download`, `jobs`, `cancel` — the settings/save_image commands
exist on the host but our download-folder and thumbnail/banner downloads go through
`chrome.downloads.download` instead, which needs no native round-trip.

Our own from-scratch `native-host/host.mjs` + `install.ps1` are no longer wired up (this host
replaces them) but are left in place in case the Sqrage host ever isn't available on a machine.
