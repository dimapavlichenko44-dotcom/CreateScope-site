#!/usr/bin/env node
// Chrome Native Messaging host for the CreateScope extension.
// Speaks two protocols over the SAME stdio connection, distinguished by which field the request
// carries: {action: ...} for transcript fetching (already wired up in the extension — see
// src/background/native/NativeTranscriptHostClient.ts), and {command: ...} for video downloading,
// which mirrors the real com.sqrage.youtube_media protocol (see SQRAGE_PROTOCOL.md) so it's a drop-in
// alternative for anyone who doesn't have that separate, already-installed third-party tool.
// Shells out to yt-dlp + ffmpeg (external tools, not bundled here) to do the actual work.
import { spawn, spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const configPath = path.join(__dirname, 'config.json');
// install.ps1 writes this with PowerShell's `-Encoding utf8`, which always prepends a BOM —
// JSON.parse throws on a leading BOM, so strip it before parsing.
const config = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, 'utf8').replace(/^﻿/, '')) : {};

const YT_DLP = config.ytDlpPath || 'yt-dlp';
const FFMPEG = config.ffmpegPath || 'ffmpeg';
const DOWNLOAD_DIR = config.downloadDir || path.join(os.homedir(), 'Downloads', 'YouTubeResearchToolkit');
const JOBS_FILE = path.join(__dirname, 'jobs.json');

fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

// ---- Worker mode: `node host.mjs --worker <jobId> <argsJson>` ----
// A `download` command must respond immediately (one-shot sendNativeMessage — see the class comment
// on NativeHostClient.ts), so the actual yt-dlp run can't happen in this process: whatever answers
// the request is gone the moment Chrome gets its reply. Instead this process re-spawns ITSELF as a
// detached worker (survives after the parent exits) that owns the real yt-dlp child, tails its
// progress, and persists state to jobs.json — every later `jobs` poll (a fresh process, no shared
// memory) just reads that file back.
if (process.argv[2] === '--worker') {
  await runWorker(process.argv[3], JSON.parse(process.argv[4]));
  process.exit(0);
}

// ---- jobs.json persistence ----

function readJobs() {
  try {
    return JSON.parse(fs.readFileSync(JOBS_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeJobs(jobs) {
  fs.writeFileSync(JOBS_FILE, JSON.stringify(jobs), 'utf8');
}

function updateJob(jobId, patch) {
  const jobs = readJobs();
  const idx = jobs.findIndex((j) => j.jobId === jobId);
  if (idx === -1) return;
  jobs[idx] = { ...jobs[idx], ...patch };
  writeJobs(jobs);
}

async function runWorker(jobId, args) {
  updateJob(jobId, { status: 'downloading', pid: process.pid });

  const PROGRESS_RE = /\[download\]\s+([\d.]+)%(?:\s+of\s+\S+)?(?:\s+at\s+(\S+))?(?:\s+ETA\s+(\S+))?/;
  let lastLine = '';

  await new Promise((resolve) => {
    const child = spawn(YT_DLP, args, { windowsHide: true });
    let stderr = '';

    child.stdout.on('data', (d) => {
      const text = d.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        lastLine = line;
        const match = PROGRESS_RE.exec(line);
        if (match) {
          updateJob(jobId, {
            status: 'downloading',
            percent: parseFloat(match[1]),
            speed: match[2] ?? undefined,
            eta: match[3] ?? undefined,
          });
        } else if (/^\[Merger\]/.test(line)) {
          updateJob(jobId, { status: 'processing', stage: 'Merging video and audio' });
        } else if (/^\[ExtractAudio\]/.test(line)) {
          updateJob(jobId, { status: 'processing', stage: 'Extracting audio' });
        } else if (/^\[VideoConvertor\]|^\[Fixup/.test(line)) {
          updateJob(jobId, { status: 'processing', stage: 'Finalizing' });
        }
      }
    });
    child.stderr.on('data', (d) => (stderr += d));
    child.on('error', (err) => {
      updateJob(jobId, { status: 'failed', error: err.message });
      resolve();
    });
    child.on('close', (code) => {
      if (code === 0) {
        updateJob(jobId, { status: 'completed', percent: 100 });
      } else {
        updateJob(jobId, { status: 'failed', error: (stderr.trim() || lastLine || `yt-dlp exited with code ${code}`).slice(0, 500) });
      }
      resolve();
    });
  });
}

// ---- Native messaging framing (4-byte LE length prefix + UTF-8 JSON body) ----

function writeMessage(message) {
  const json = Buffer.from(JSON.stringify(message), 'utf8');
  const header = Buffer.alloc(4);
  header.writeUInt32LE(json.length, 0);
  process.stdout.write(header);
  process.stdout.write(json);
}

let inputBuffer = Buffer.alloc(0);
process.stdin.on('data', (chunk) => {
  inputBuffer = Buffer.concat([inputBuffer, chunk]);
  while (inputBuffer.length >= 4) {
    const len = inputBuffer.readUInt32LE(0);
    if (inputBuffer.length < 4 + len) break;
    const body = inputBuffer.slice(4, 4 + len);
    inputBuffer = inputBuffer.slice(4 + len);
    try {
      handleRequest(JSON.parse(body.toString('utf8')));
    } catch (err) {
      writeMessage({ id: null, type: 'error', message: `Malformed request: ${String(err)}` });
    }
  }
});
process.stdin.on('end', () => process.exit(0));

// ---- yt-dlp helpers (status/formats — synchronous one-shot calls, fine since these commands
// respond within this same process rather than needing the detached-worker treatment). ----

function runYtDlpJson(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(YT_DLP, args, { windowsHide: true });
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', (d) => (stdout += d));
    proc.stderr.on('data', (d) => (stderr += d));
    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(stderr.trim() || `yt-dlp exited with code ${code}`));
      try {
        resolve(JSON.parse(stdout));
      } catch (err) {
        reject(new Error(`Failed to parse yt-dlp output: ${String(err)}`));
      }
    });
  });
}

function getYtdlpVersion() {
  try {
    const res = spawnSync(YT_DLP, ['--version'], { windowsHide: true, encoding: 'utf8' });
    if (res.error || res.status !== 0) return null;
    return res.stdout.trim();
  } catch {
    return null;
  }
}

/** One representative format per distinct height — a Best-effort dedupe: prefer a format that
 * already carries audio (so playback works standalone), then the highest bitrate at that height. */
function dedupeFormatsByHeight(rawFormats) {
  const byHeight = new Map();
  for (const f of rawFormats) {
    if (!f.height || !f.vcodec || f.vcodec === 'none') continue;
    const hasAudio = !!(f.acodec && f.acodec !== 'none');
    const score = (hasAudio ? 1_000_000 : 0) + (f.tbr ?? 0);
    const existing = byHeight.get(f.height);
    const existingScore = existing ? (existing.hasAudio ? 1_000_000 : 0) + (existing.tbr ?? 0) : -1;
    if (!existing || score > existingScore) byHeight.set(f.height, { ...f, hasAudio, tbr: f.tbr ?? 0 });
  }
  return [...byHeight.values()].sort((a, b) => b.height - a.height);
}

function qualityToFormatSelector(req) {
  if (req.videoHasAudio) return req.videoFormatId;
  return `${req.videoFormatId}+bestaudio/best`;
}

// ---- Transcript (yt-dlp bypasses the browser's PO-token wall by using a non-web client, e.g.
// "android vr" — a plain fetch() to the timedtext endpoint from the page now returns 200 with an
// empty body without one) ----

function runYtDlpInfo(url) {
  return runYtDlpJson(['-J', '--no-warnings', '--skip-download', url]);
}

const PROGRESS_RE_SIMPLE = /\[download\]\s+([\d.]+)%/;

function runYtDlpDownload(args, onProgress) {
  return new Promise((resolve, reject) => {
    const proc = spawn(YT_DLP, args, { windowsHide: true });
    let stderr = '';
    let lastLine = '';

    proc.stdout.on('data', (d) => {
      const text = d.toString('utf8');
      lastLine = text.trim().split('\n').pop() ?? lastLine;
      const match = PROGRESS_RE_SIMPLE.exec(text);
      if (match) onProgress(parseFloat(match[1]));
    });
    proc.stderr.on('data', (d) => (stderr += d));
    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(stderr.trim() || lastLine || `yt-dlp exited with code ${code}`));
      resolve();
    });
  });
}

/** Downloads exactly one subtitle track to a scratch dir, parses the json3 event stream, cleans up. */
async function downloadOneTrack(url, lang, source) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ytr-sub-'));
  try {
    const args = [
      source === 'manual' ? '--write-subs' : '--write-auto-subs',
      '--skip-download',
      '--sub-langs',
      lang,
      '--sub-format',
      'json3',
      '--no-warnings',
      '-o',
      path.join(tmpDir, 'sub'),
      url,
    ];
    await runYtDlpDownload(args, () => {});
    const file = fs.readdirSync(tmpDir).find((f) => f.endsWith('.json3'));
    if (!file) return null;
    const json = JSON.parse(fs.readFileSync(path.join(tmpDir, file), 'utf8'));
    const segments = (json.events ?? [])
      .filter((e) => e.segs)
      .map((e) => {
        const text = e.segs
          .map((s) => s.utf8 ?? '')
          .join('')
          .replace(/\n/g, ' ')
          .trim();
        const start = (e.tStartMs ?? 0) / 1000;
        const duration = (e.dDurationMs ?? 0) / 1000;
        return { start, end: start + duration, text };
      })
      .filter((s) => s.text);
    return segments;
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

/**
 * Priority (spec): manual in a preferred language -> auto in a preferred language -> manual in the
 * video's original/any available language -> auto in the video's original/any available language ->
 * unavailable. `preferredLangs` should already be ordered most- to least-preferred by the caller.
 */
async function getTranscript(videoId, preferredLangs) {
  const url = `https://www.youtube.com/watch?v=${videoId}`;
  const info = await runYtDlpInfo(url);
  const manual = info.subtitles ?? {};
  const auto = info.automatic_captions ?? {};

  const pickFrom = (dict, langs) => langs.find((l) => dict[l]) ?? null;

  let lang = pickFrom(manual, preferredLangs);
  let source = 'manual';
  if (!lang) {
    lang = pickFrom(auto, preferredLangs);
    source = 'auto';
  }
  if (!lang && Object.keys(manual).length) {
    lang = Object.keys(manual)[0];
    source = 'manual';
  }
  if (!lang && Object.keys(auto).length) {
    lang = Object.keys(auto)[0];
    source = 'auto';
  }
  if (!lang) return { available: false };

  const segments = await downloadOneTrack(url, lang, source);
  if (!segments || segments.length === 0) return { available: false };
  return { available: true, language: lang, source, segments };
}

// ---- {command: ...} handlers — mirrors SQRAGE_PROTOCOL.md exactly (plain {ok, ...} replies, no
// id/type envelope) so NativeHostClient.ts works against this host completely unchanged. ----

async function handleCommand(req) {
  const { command } = req;

  if (command === 'status') {
    const version = getYtdlpVersion();
    if (!version) return writeMessage({ ok: true, ready: false, message: `yt-dlp not found (looked for "${YT_DLP}").` });
    return writeMessage({ ok: true, ready: true, ytdlpVersion: version });
  }

  if (command === 'formats') {
    try {
      const info = await runYtDlpJson(['-J', '--no-warnings', '--no-playlist', req.url]);
      const formats = dedupeFormatsByHeight(info.formats ?? []).map((f) => ({
        quality: f.height,
        formatId: f.format_id,
        width: f.width ?? 0,
        height: f.height,
        fps: Math.round(f.fps ?? 0),
        hdr: /hdr/i.test(f.dynamic_range ?? '') || /hdr/i.test(f.format_note ?? ''),
        hasAudio: f.hasAudio,
      }));
      return writeMessage({ ok: true, formats, maxQuality: formats[0]?.height ?? null });
    } catch (err) {
      return writeMessage({ ok: false, message: err instanceof Error ? err.message : String(err) });
    }
  }

  if (command === 'download') {
    const jobId = crypto.randomUUID();
    const jobs = readJobs();
    jobs.push({ jobId, status: 'queued', title: req.title });
    writeJobs(jobs);

    const outTemplate = path.join(DOWNLOAD_DIR, '%(title).150B_%(id)s.%(ext)s');
    const args = ['--no-warnings', '--newline', '--ffmpeg-location', FFMPEG, '-o', outTemplate];
    if (req.mode === 'audio') {
      args.push('-x', '--audio-format', req.audioFormat === 'mp3' ? 'mp3' : 'best');
    } else {
      args.push('-f', qualityToFormatSelector(req), '--merge-output-format', 'mp4');
    }
    args.push(req.url);

    // Detached + unref'd so it outlives this process — Chrome closes this connection right after
    // reading the reply below (sendNativeMessage is one-shot, see NativeHostClient.ts), and a plain
    // child would be killed along with it. stdio 'ignore' since progress comes from jobs.json, not
    // from anything this now-dead process could still be listening to.
    const worker = spawn(process.execPath, [__filename, '--worker', jobId, JSON.stringify(args)], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    worker.unref();

    return writeMessage({ ok: true });
  }

  if (command === 'jobs') {
    const jobs = readJobs();
    const activeCount = jobs.filter((j) => j.status === 'queued' || j.status === 'downloading' || j.status === 'processing').length;
    return writeMessage({ ok: true, jobs, activeCount });
  }

  if (command === 'cancel') {
    const jobs = readJobs();
    const job = jobs.find((j) => j.jobId === req.jobId);
    if (job?.pid) {
      // Windows-only (this project targets Windows) — plain process.kill() only signals the
      // immediate PID, leaving yt-dlp's own ffmpeg child running; /T kills the whole process tree.
      try {
        spawnSync('taskkill', ['/F', '/T', '/PID', String(job.pid)], { windowsHide: true });
      } catch {
        // best-effort — the job below still gets marked cancelled either way
      }
    }
    updateJob(req.jobId, { status: 'cancelled' });
    return writeMessage({ ok: true });
  }

  if (command === 'clear_finished') {
    const jobs = readJobs().filter((j) => !['completed', 'failed', 'cancelled'].includes(j.status));
    writeJobs(jobs);
    return writeMessage({ ok: true });
  }

  writeMessage({ ok: false, message: `Unknown command: ${command}` });
}

// ---- {action: ...} handlers (unchanged — already wired up for transcript fetching) ----

async function handleAction(req) {
  const { id, action } = req;
  try {
    if (action === 'ping') {
      writeMessage({ id, type: 'pong', ytDlp: YT_DLP, ffmpeg: FFMPEG, downloadDir: DOWNLOAD_DIR });
      return;
    }

    if (action === 'getFormats') {
      const url = `https://www.youtube.com/watch?v=${req.videoId}`;
      const info = await runYtDlpJson(['-J', '--no-warnings', '--ffmpeg-location', FFMPEG, url]);
      const formats = (info.formats ?? [])
        .filter((f) => f.vcodec !== 'none' && f.height)
        .map((f) => ({ itag: f.format_id, height: f.height, ext: f.ext, filesize: f.filesize ?? null }))
        .sort((a, b) => b.height - a.height);
      writeMessage({ id, type: 'formats', formats });
      return;
    }

    if (action === 'download') {
      const url = `https://www.youtube.com/watch?v=${req.videoId}`;
      const outTemplate = path.join(DOWNLOAD_DIR, '%(title).150B_%(id)s.%(ext)s');
      const args = ['--no-warnings', '--newline', '--ffmpeg-location', FFMPEG, '-o', outTemplate];

      if (req.mode === 'audio') {
        args.push('-x', '--audio-format', req.audioFormat === 'mp3' ? 'mp3' : 'best');
      } else {
        args.push('-f', 'bv*+ba/b', '--merge-output-format', 'mp4');
      }
      args.push(url);

      await runYtDlpDownload(args, (percent) => writeMessage({ id, type: 'progress', percent }));
      writeMessage({ id, type: 'done', downloadDir: DOWNLOAD_DIR });
      return;
    }

    if (action === 'getTranscript') {
      const languages = Array.isArray(req.languages) && req.languages.length ? req.languages : ['en'];
      const result = await getTranscript(req.videoId, languages);
      writeMessage({ id, type: 'transcript', ...result });
      return;
    }

    writeMessage({ id, type: 'error', message: `Unknown action: ${action}` });
  } catch (err) {
    writeMessage({ id, type: 'error', message: err instanceof Error ? err.message : String(err) });
  }
}

// ---- Request handling ----

async function handleRequest(req) {
  if (req.command) return handleCommand(req);
  return handleAction(req);
}
