# Registers the CreateScope native messaging host for the current Windows user.
# Run this yourself after loading the extension unpacked (chrome://extensions -> Developer mode
# -> Load unpacked -> select the dist/ folder). Fully self-contained: if yt-dlp/ffmpeg aren't found
# anywhere on this machine, this script downloads portable copies itself (into a "tools" folder next
# to this script) - no separate manual setup needed.
#
# Usage:
#   Easiest: double-click install.bat (runs this script with an execution-policy bypass and pauses
#   at the end so you can read the output).
#   Or directly:
#     .\install.ps1
#
# Optional:
#   -ExtensionId "abcdefghijklmnopabcdefghijklmnop"
#       Only needed if you're loading a DIFFERENT build than the one this repo ships - the packaged
#       extension's manifest.json has a fixed "key", which makes its Chrome extension ID constant
#       (independently verified: eceboaogflfkcaihnjlhonidblnnnidc) regardless of who installs it or
#       which machine it's loaded on, so there's normally nothing to copy-paste from chrome://extensions.
#   -YtDlpPath   "C:\path\to\yt-dlp.exe"   (skips auto-download; also checks PATH and known local installs first)
#   -FfmpegPath  "C:\path\to\ffmpeg.exe"   (same, for ffmpeg)
#   -DownloadDir "D:\Downloads\YTR"        (defaults to Downloads\YouTubeResearchToolkit)

param(
    [string]$ExtensionId = "eceboaogflfkcaihnjlhonidblnnnidc",

    [string]$YtDlpPath,
    [string]$FfmpegPath,
    [string]$DownloadDir
)

$ErrorActionPreference = "Stop"
$hostDir = $PSScriptRoot
$toolsDir = Join-Path $hostDir "tools"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Error "Node.js was not found on PATH. Install Node.js first (https://nodejs.org)."
    exit 1
}

function Find-ExistingBinary($fileName, $fallbackCandidates) {
    foreach ($candidate in $fallbackCandidates) {
        if (Test-Path $candidate) { return $candidate }
    }
    $onPath = Get-Command $fileName -ErrorAction SilentlyContinue
    if ($onPath) { return $onPath.Source }
    return $null
}

function Test-DownloadedExe($path) {
    return (Test-Path $path) -and ((Get-Item $path).Length -gt 100KB)
}

# ---- yt-dlp: a single portable .exe, published directly as a GitHub release asset. ----
function Get-YtDlp {
    $existing = Find-ExistingBinary "yt-dlp" @(
        "$env:LOCALAPPDATA\SqrageYouTubeIdeaSaver\yt-dlp.exe",
        "$env:LOCALAPPDATA\SqrageYouTubeDownloader\yt-dlp.exe"
    )
    if ($existing) { return $existing }

    $target = Join-Path $toolsDir "yt-dlp.exe"
    if (Test-DownloadedExe $target) { return $target }

    Write-Output "yt-dlp not found anywhere on this machine - downloading a portable copy..."
    New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null
    Invoke-WebRequest -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile $target -UseBasicParsing
    if (-not (Test-DownloadedExe $target)) {
        throw "yt-dlp download did not produce a valid executable at $target"
    }
    Write-Output "  -> $target"
    return $target
}

# ---- ffmpeg: no single official .exe - BtbN's "latest" release on GitHub is a well-known, commonly
# used source for portable static Windows builds. Ships as a zip (ffmpeg.exe + ffprobe.exe + docs);
# only the two binaries are kept, everything else is discarded after extraction. ----
function Get-Ffmpeg {
    $existing = Find-ExistingBinary "ffmpeg" @(
        "$env:LOCALAPPDATA\SqrageYouTubeIdeaSaver\ffmpeg.exe",
        "$env:LOCALAPPDATA\SqrageYouTubeDownloader\ffmpeg.exe"
    )
    if ($existing) { return $existing }

    $target = Join-Path $toolsDir "ffmpeg.exe"
    if (Test-DownloadedExe $target) { return $target }

    Write-Output "ffmpeg not found anywhere on this machine - downloading a portable copy (this one's ~170MB, may take a minute)..."
    New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null
    $zipPath = Join-Path $toolsDir "ffmpeg-download.zip"
    $extractDir = Join-Path $toolsDir "ffmpeg-extract"
    try {
        Invoke-WebRequest -Uri "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" -OutFile $zipPath -UseBasicParsing
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

        $ffmpegExe = Get-ChildItem -Path $extractDir -Filter "ffmpeg.exe" -Recurse | Select-Object -First 1
        $ffprobeExe = Get-ChildItem -Path $extractDir -Filter "ffprobe.exe" -Recurse | Select-Object -First 1
        if (-not $ffmpegExe) { throw "ffmpeg.exe not found inside the downloaded archive" }
        Copy-Item $ffmpegExe.FullName -Destination $target -Force
        if ($ffprobeExe) { Copy-Item $ffprobeExe.FullName -Destination (Join-Path $toolsDir "ffprobe.exe") -Force }
    } finally {
        if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
        if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
    }
    if (-not (Test-DownloadedExe $target)) {
        throw "ffmpeg download did not produce a valid executable at $target"
    }
    Write-Output "  -> $target"
    return $target
}

if (-not $YtDlpPath) { $YtDlpPath = Get-YtDlp }
if (-not $FfmpegPath) { $FfmpegPath = Get-Ffmpeg }
if (-not $DownloadDir) {
    $DownloadDir = Join-Path $env:USERPROFILE "Downloads\YouTubeResearchToolkit"
}
New-Item -ItemType Directory -Force -Path $DownloadDir | Out-Null

$config = @{
    ytDlpPath   = $YtDlpPath
    ffmpegPath  = $FfmpegPath
    downloadDir = $DownloadDir
} | ConvertTo-Json
Set-Content -Path (Join-Path $hostDir "config.json") -Value $config -Encoding utf8

$hostBatPath = (Join-Path $hostDir "host.bat").Replace("\", "\\")
$manifest = @{
    name             = "com.ytresearchtoolkit.host"
    description      = "CreateScope local download helper"
    path             = (Join-Path $hostDir "host.bat")
    type             = "stdio"
    allowed_origins  = @("chrome-extension://$ExtensionId/")
} | ConvertTo-Json
$manifestPath = Join-Path $hostDir "com.ytresearchtoolkit.host.json"
Set-Content -Path $manifestPath -Value $manifest -Encoding utf8

# Every Chromium-based browser keeps its own separate native-messaging registry key (they don't
# share Chrome's) - registered under each so the extension works regardless of which one the user
# actually has installed. Missing a browser here is harmless: New-Item just creates that browser's
# key fresh, it doesn't need to already exist or that browser to be installed.
$registryRoots = @(
    "HKCU:\Software\Google\Chrome\NativeMessagingHosts",
    "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts",
    "HKCU:\Software\Opera Software\NativeMessagingHosts",
    "HKCU:\Software\BraveSoftware\NativeMessagingHosts"
)
foreach ($root in $registryRoots) {
    $regKey = Join-Path $root "com.ytresearchtoolkit.host"
    New-Item -Path $regKey -Force | Out-Null
    Set-ItemProperty -Path $regKey -Name "(Default)" -Value $manifestPath
}

Write-Output ""
Write-Output "Installed native messaging host 'com.ytresearchtoolkit.host'."
Write-Output "  yt-dlp:   $YtDlpPath"
Write-Output "  ffmpeg:   $FfmpegPath"
Write-Output "  output:   $DownloadDir"
Write-Output "  manifest: $manifestPath"
Write-Output ""
Write-Output "Reload the extension (chrome://extensions -> reload) and Download should work."
